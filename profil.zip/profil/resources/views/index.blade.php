<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> Dila's Profile </title>
</head>
<body>
    
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title> PROFIL SINGKAT DILA ROSELAWATI｜</title>
<link rel='dns-prefetch' href='//use.fontawesome.com' />


<link data-minify="1" rel='stylesheet' id='stk_style-css'  href='https://h6a2k6j6.rocketcdn.me/wp-content/cache/min/1/wp-content/themes/jstork19/style.css?ver=1631635390' type='text/css' media='all' />
<style id='stk_style-inline-css' type='text/css'>
@media only screen and (min-width:980px){.sidebar_none #main{margin:0 auto;width:100%;max-width:inherit}.sidebar_none .archives-list.card-list::after,.sidebar_none .archives-list.card-list .post-list{width:calc(33.3333% - 1em)}.sidebar_none .archives-list.card-list::after{content:""}.sidebar_none .archives-list:not(.card-list){margin:2em auto 0;max-width:800px}}
@media only screen and (max-width:480px){#toc_container{font-size:90%}}#toc_container{width:100%!important;padding:1.2em;border:5px solid rgba(100,100,100,.2)}#toc_container li{margin:1em 0;font-weight:bold}#toc_container li li{font-weight:normal;margin:.5em 0}#toc_container li::before{content:none}#toc_container .toc_number{display:inline-block;font-weight:bold;font-size:75%;background-color:var(--main-ttl-bg);color:var(--main-ttl-color);min-width:2.1em;min-height:2.1em;line-height:2.1;text-align:center;border-radius:1em;margin-right:.3em;padding:0 7px}#toc_container a{color:inherit;text-decoration:none}#toc_container a:hover{text-decoration:underline}#toc_container p.toc_title{max-width:580px;font-weight:bold;text-align:left;margin:0 auto;font-size:100%;vertical-align:middle}#toc_container .toc_title::before{display:inline-block;font-family:"Font Awesome 5 Free";font-weight:900;content:"\f03a";margin-right:.8em;margin-left:.4em;transform:scale(1.4);color:var(--main-ttl-bg)}#toc_container .toc_title .toc_toggle{font-size:80%;font-weight:normal;margin-left:.2em}#toc_container .toc_list{max-width:580px;margin-left:auto;margin-right:auto}#toc_container .toc_list>li{padding-left:0}
:root{--main-text-color:#212121;--main-link-color:#1862c9;--main-link-color-hover:#1862c9;--main-ttl-bg:#212121;--main-ttl-bg-rgba:rgba(33,33,33,.1);--main-ttl-color:#fff;--header-bg:#fff;--header-logo-color:#757575;--header-text-color:#212121;--inner-content-bg:#fff;--label-bg:#fff;--label-text-color:#212121;--slider-text-color:#212121;--side-text-color:#212121;--footer-bg:#fff;--footer-text-color:#212121;--footer-link-color:#212121;--new-mark-bg:#757575;--oc-box-blue:#82c8e2;--oc-box-blue-inner:#d4f3ff;--oc-box-red:#ee5656;--oc-box-red-inner:#feeeed;--oc-box-yellow:#ded647;--oc-box-yellow-inner:#fff8d4;--oc-box-green:#79e37c;--oc-box-green-inner:#d8f7c3;--oc-box-pink:#f7b2b2;--oc-box-pink-inner:#fee;--oc-box-gray:#9c9c9c;--oc-box-gray-inner:#f5f5f5;--oc-box-black:#313131;--oc-box-black-inner:#404040}
</style>
<link data-minify="1" rel='stylesheet' id='fontawesome-css'  href='https://h6a2k6j6.rocketcdn.me/wp-content/cache/min/1/releases/v5.13.0/css/all.css?ver=1631635390' type='text/css' media='all' />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://h6a2k6j6.rocketcdn.me/wp-includes/wlwmanifest.xml" /> 
<meta name="google-site-verification" content="JwllSZf-BMNuYo_qCRGcuFVmh_YxZuubBxpFQwseal8" /><style type="text/css" id="custom-background-css">
body.custom-background { background-color: #ffffff; }
</style>
		<style type="text/css" id="wp-custom-css">
			a{ text-decoration:none;	}

		</style>
		
<body class="post-template post-template-single-full post-template-single-full-php single single-post postid-7284 single-format-standard custom-background wp-embed-responsive headercenter h_boader gf_none bgfull">

<div id="container">
<div id="content">
<div id="inner-content" class="fadeIn wrap page-full wide cf">
<main id="main">
<article id="post-7284" class="post-7284 post type-post status-publish format-standard has-post-thumbnail hentry category-memo article">

<p class="byline entry-meta vcard cf"><span class="cat-name cat-id-127">Yahalo~</span>
<h1 class="entry-title single-title" itemprop="headline" rel="bookmark">PROFIL SINGKAT DILA ROSELAWATI</h1>

<img width="1200" height="675" src="img/images.png" alt="TYa-neko" loading="lazy" srcset="img/images.png" sizes="(max-width: 1200px) 100vw, 1200px"/>

<section class="entry-content cf">
<p> Untuk keperluan tugas UTS Pemrogaram Framework, saya membuat sebuah website sederhana yang berisikan tentang profil pribadi saya. </p>
<p> Saya akan menulis profil atau mungkin ketertarikan saya disini. </p>
<p> Saya adalah seorang Mahasiswi D4 Manajemen Informatika D4 2019 B semester 5, memiliki ketertarikan di beberapa bidang dalam teknik informatika ini. </p>
<p> Salah satunya adalah memiliki ketertarikan dalam pembuatan game dan pembuatan web statis. </p>
<p> Untuk jaringan saya memiliki ketertarikan juga pada semester sebelumnya, namun karena di semester ini tidak diajarkan jadi belum bisa mendalami secara paham dan detail. </p>


<div id="toc_container" class="toc_white no_bullets"><p class="toc_title"> Daftar Isi </p>
<ul class="toc_list"><li><a href="#i"> Apa itu layanan pembuatan situs profil? </a></li>
<li><a href="#Profil">Profil</a></li>
<li><a href="#Motton">Moto</a></li>
<li><a href="#i-3"> Mari Kita Manfaatkan Situs Pembuatan Profil </a>
<h2><span id="i"> Apa itu layanan pembuatan situs profil? </span></h2>

<img loading="lazy" width="1200" height="400" src="img/WhatsApp Image 2021-10-13 at 12.52.45.jpeg" alt="Tya-neko2" srcset="img/WhatsApp Image 2021-10-13 at 12.52.45.jpeg" sizes="(max-width: 1200px) 100vw, 1200px"/>


<p> Situs profil (profesional situs) adalah layanan yang berguna ketika Anda harus memperkenalkan diri dengan jumlah tautan terbatas atau jumlah karakter tetap di SNS. </p>
<p> Situs profil dapat mengumpulkan banyak informasi tentang si empunya website. </p>
<p>Sangat berguna untuk membuat portofolio seperti karir dan prestasi. </p>

<h2><span id="Profil">Profil dan layanan media sosial </span></h2>
<p> Maaf atas penjelasan singkat tentang saya, dibawah saya tuliskan beberapa media sosial yang saya gunakan. </p>
<p> Didalam link tersebut anda juga dapat menemukan tentang profil lengkap dan hobi saya. </p>
<p> Silahkan kunjungi dan <strong> follow </strong> ya :) s</p>
<ol><li>Email: <a href="dilarosela118@gmail.com" target="_blank" rel="noreferrer noopener">dilarosela118@gmail.com</a></li>
<li>LinkedIn: <a href="https://www.linkedin.com/in/dila-roselawati-0a720b1b4" target="_blank" rel="noreferrer noopener"> Dila Roselawati </a></li>
<li>Twitter: <a href="https://twitter.com/RosellDila" rel="noreferrer noopener" target="_blank">ABC-Dila</a></li></ol>


<h2><span id="Motton">Moto</span></h2>
<p> Moto itu sendiri merupakan bagian yang sangat penting untuk menjelaskan apa motivasi kita dalam menjalankan hidup. </p>
<p> Setiap orang pasti memiliki moto, atau kata-kata yang bisa membuat orang tersebut menjadi <strong>「kuat dan berkemauan」</strong> untuk melakukan apa yang diminatinya nantinya.</p>
<p> Moto saya sendiri adalah <strong> selalu mengikuti apa yang kamu percaya dan inginkan </strong>, meskipun memiliki mayoritas pilihan yang berbeda dengan yang saya pilih. Saya tidak pernah menyesal dengan pilihan tersebut. </p>
<p> Saya lebih suka sesuatu yang simpel, dan dapat dipikir secara logika. Tidak terlalu membuang-buang waktu dengan memikir dua kali untuk hasil jawaban yang sama. </p>

<h2><span id="i-3"> Mari Kita Manfaatkan Situs Pembuatan Profil </span></h2>

<img loading="lazy" width="1200" height="400" src="img/E5ko-UeVoAAgmhy.jpeg" alt=" KuroKurori " srcset="img/E5ko-UeVoAAgmhy.jpeg" sizes="(max-width: 1200px) 100vw, 1200px"/>

<p> Banyak layanan web telah digunakan di situs pembuatan profil.
<p> Sebaiknya coba dulu, lalu ubah konten untuk ditangani sesuai dengan masing-masing situs profil. </p>
<p> Hal tersebut untuk memudahkan kita yang tidak terlalu mendalami tentang ilmu per-codingan. s</p>

<h2 id="block-93b8ea10-9fbc-447c-8f5b-2197d258fec9"><span id="_SNS"> Ringkasan: Monetisasi dengan menautkan SNS dan media blog </span></h2>
<img loading="lazy" width="1200" height="400" src="img/1.jpg" alt=" monet" srcset="img/1.jpg" sizes="(max-width: 1200px) 100vw, 1200px"/>

<p> Jika dapat memilih dan mengembangkan media sosial yang sesuai dengan kita di antara banyak aplikasi media sosial yang telah dirilis, kita akan dapat secara dramatis meningkatkan kemampuan untuk menyebarkan informasi. </p>
<p> Ada banyak platform untuk media sosial yang dapat dengan mudah dimonetisasi hanya dengan smartphone, mungkin kita bisa memulai dengan Facebook atau Twitter yang penggunanya paling banyak dalam ranah SNS. </p>
</section>
<footer class="article-footer">
<ul class="post-categories">
	<li><a href=" " rel="category tag">Yahalo~</a></li></ul></footer>
</article>

<div id="authorbox">
<h2 class="h_ttl"><span class="gf">ABOUT ME</span></h2>
<div class="author_info"><div class="author_name"> Dila Roselawati <span class="userposition"> Universitas Negeri Surabaya </span></div><div class="author_description">
<p style="margin-bottom:1em;"> Halo, saya Dila Roselawati. </p>
<p style="margin-bottom:1em;"> Saya mulai berkuliah di Universitas Negeri Surabaya pada juli 2019.</p>
<p style="margin-bottom:1em;"> Sudah hampir 2 tahun Corona di Indonesia terjadi, dan selama pertengahan semester 2 kami diberlakukan pembelajaran secara online. </p>
<p style="margin-bottom:1em;"> Saya jurusan D4 Manajemen Informatika 2019 B, dan sekarang masih semeste 5. </p>
<p style="margin-bottom:1em;"> Semoga dengan Anda membaca profil saya dan mengunjungi web situs SNS (media sosial) yang telah saya cantumkan diatas dapat membuat jarak kita menjadi lebih dekat (wkwk) </p>
</div></div>
</div>
</div>
</main>
</div>
</div>

<div id="breadcrumb" class="breadcrumb fadeIn pannavi_on_bottom">
    <div class="wrap"><ul class="breadcrumb__ul" itemscope itemtype="http://schema.org/BreadcrumbList">
    <span itemprop="name"> HOME | </span></a>
<meta itemprop="position" content="1" /></li><span itemprop="name">Yahalo~</span></a>
<meta itemprop="position" content="2" /></li><li class="breadcrumb__li" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem" class="bc_posttitle">
<span itemprop="name">PROFIL SINGKAT DILA ROSELAWATI</span>
<meta itemprop="position" content="3" /></li></ul></div></div>
</form>
<footer id="footer" class="footer">
	<div id="inner-footer" class="inner wrap cf">
		</div>
		</div>
		<div id="footer-bottom">
			<p class="source-org copyright">&copy;Copyright 2021. All Rights Reserved.</p>		
      </div>
	</div>
</footer>
</div>
			
</body>
</html>